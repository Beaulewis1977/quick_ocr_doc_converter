#!/usr/bin/env python3
"""
Universal Document Converter - Complete Enterprise Solution
Complete GUI application with OCR, document conversion, markdown tools, API management, and VB6/VFP9 integration
Designed and built by Beau Lewis (blewisxx@gmail.com)

Complete Feature Set:
- Full OCR functionality (Tesseract, EasyOCR, Google Vision API)
- Complete document conversion (DOCX, PDF, TXT, HTML, RTF, EPUB, Markdown)
- Bidirectional markdown converter with markdown reader
- API management for cloud OCR services
- VB6/VFP9 legacy system integration interface
- Advanced settings with tabbed configuration
- Multi-threaded processing with hardened security
- Drag-and-drop support with comprehensive file validation
- Cross-platform compatibility (Windows, macOS, Linux)
- Professional GUI with advanced tools and settings
- Enterprise-grade logging and error handling
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import os
from pathlib import Path
import sys
import mimetypes
import re
import logging
import datetime
import json
import subprocess
import shutil
from typing import Optional, Union, Dict, Any, List
import concurrent.futures
import time
import hashlib
from threading import Lock
import webbrowser
import gc

# Configuration management
from config.defaults import config_manager

# OCR and document processing imports
try:
    from ocr_engine.ocr_engine import OCREngine
    from ocr_engine.ocr_integration import OCRIntegration
    from ocr_engine.format_detector import OCRFormatDetector
    from ocr_engine.security import SecurityError, validate_file_path
    HAS_OCR = True
except ImportError:
    HAS_OCR = False
    OCREngine = None

# Document conversion imports
try:
    from convert_to_markdown import convert_docx_to_markdown, convert_pdf_to_markdown
    from convert_recursive import convert_directory
    HAS_MARKDOWN = True
except ImportError:
    HAS_MARKDOWN = False

# Cloud API imports
try:
    from google.cloud import vision
    HAS_GOOGLE_VISION = True
except ImportError:
    HAS_GOOGLE_VISION = False

class UniversalDocumentConverter:
    """
    Complete Universal Document Converter with all features integrated
    """
    
    def __init__(self, root):
        self.root = root
        self.root.title("Universal Document Converter - Complete Enterprise Solution v3.1.0")
        self.root.geometry("1200x800")
        self.root.minsize(800, 600)
        
        # Application state
        self.is_processing = False
        self.processing_thread = None
        self.processed_count = 0
        self.total_files = 0
        self.cancel_processing = False
        self.failed_count = 0
        self.skipped_count = 0
        self.start_time = None
        
        # Caching system
        self.conversion_cache = {}
        self.cache_lock = Lock()
        self.max_cache_size = config_manager.get('cache.max_size_mb', 100) * 1024 * 1024  # Configurable cache limit
        self.current_cache_size = 0
        
        # OCR and conversion engines
        self.ocr_engine = None
        self.current_files = []
        
        # Configuration and settings
        self.config = self.load_config()
        self.setup_logging()
        
        # Initialize OCR if available
        if HAS_OCR:
            try:
                self.ocr_engine = OCREngine(config=self.config.get('ocr', {}))
            except Exception as e:
                logging.warning(f"Could not initialize OCR engine: {e}")
        
        # Setup UI
        self.setup_ui()
        self.setup_drag_drop()
        
        # Setup event handlers
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
    def setup_logging(self):
        """Setup logging configuration"""
        log_level = self.config.get('logging', {}).get('level', 'INFO')
        log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        
        # Create logs directory
        log_dir = Path.home() / ".universal_converter" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        # Setup file handler
        log_file = log_dir / f"converter_{datetime.datetime.now().strftime('%Y%m%d')}.log"
        
        # Store handlers for proper cleanup
        self.file_handler = logging.FileHandler(log_file)
        self.stream_handler = logging.StreamHandler()
        
        logging.basicConfig(
            level=getattr(logging, log_level.upper()),
            format=log_format,
            handlers=[
                self.file_handler,
                self.stream_handler
            ]
        )
        
        self.logger = logging.getLogger(__name__)
        self.logger.info("Universal Document Converter started")
    
    def load_config(self) -> dict:
        """Load configuration from file"""
        config_dir = Path.home() / ".universal_converter"
        config_file = config_dir / "config.json"
        
        default_config = {
            'ocr': {
                'engine': 'auto',
                'languages': ['en'],
                'confidence_threshold': 0.7,
                'use_cache': True
            },
            'conversion': {
                'preserve_formatting': True,
                'quality': 'high',
                'max_workers': 4
            },
            'api': {
                'google_vision': {
                    'enabled': False,
                    'credentials_path': '',
                    'fallback_enabled': True,
                    'fallback_preference': 'tesseract'  # Preferred fallback engine
                }
            },
            'gui': {
                'theme': 'default',
                'remember_settings': True,
                'auto_preview': False
            },
            'logging': {
                'level': 'INFO',
                'max_size': '10MB',
                'backup_count': 5
            },
            'legacy': {
                'vb6_vfp9_integration': True,
                'dll_compatibility': True
            }
        }
        
        try:
            if config_file.exists():
                with open(config_file, 'r') as f:
                    user_config = json.load(f)
                # Merge with defaults
                return {**default_config, **user_config}
        except Exception as e:
            logging.warning(f"Could not load config: {e}")
        
        return default_config
    
    def save_config(self):
        """Save configuration to file"""
        try:
            config_dir = Path.home() / ".universal_converter"
            config_dir.mkdir(parents=True, exist_ok=True)
            config_file = config_dir / "config.json"
            
            with open(config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            logging.error(f"Could not save config: {e}")
    
    def setup_ui(self):
        """Setup the complete user interface with tabbed layout"""
        # Create main container
        main_container = ttk.Frame(self.root)
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create notebook for tabbed interface
        self.notebook = ttk.Notebook(main_container)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Create all tabs
        self.create_main_tab()
        self.create_ocr_tab()
        self.create_markdown_tab()
        self.create_api_tab()
        self.create_legacy_tab()
        self.create_tools_tab()
        self.create_settings_tab()
        
        # Status bar at bottom
        self.create_status_bar(main_container)
    
    def create_main_tab(self):
        """Create main document conversion tab"""
        main_frame = ttk.Frame(self.notebook)
        self.notebook.add(main_frame, text="📄 Document Conversion")
        
        # File selection area
        file_frame = ttk.LabelFrame(main_frame, text="Files", padding=10)
        file_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # File list
        list_frame = ttk.Frame(file_frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        self.file_listbox = tk.Listbox(list_frame, selectmode=tk.EXTENDED)
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.file_listbox.yview)
        self.file_listbox.configure(yscrollcommand=scrollbar.set)
        
        self.file_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # File buttons
        btn_frame = ttk.Frame(file_frame)
        btn_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(btn_frame, text="Add Files", command=self.add_files).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_frame, text="Add Folder", command=self.add_folder).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_frame, text="Clear", command=self.clear_files).pack(side=tk.LEFT, padx=(0, 5))
        
        # Conversion options
        options_frame = ttk.LabelFrame(main_frame, text="Conversion Options", padding=10)
        options_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Create two rows of options
        options_row1 = ttk.Frame(options_frame)
        options_row1.pack(fill=tk.X, pady=(0, 5))
        options_row2 = ttk.Frame(options_frame)
        options_row2.pack(fill=tk.X)
        
        # Output format
        ttk.Label(options_row1, text="Output Format:").pack(side=tk.LEFT, padx=(0, 5))
        self.output_format = ttk.Combobox(options_row1, values=[
            "txt", "docx", "pdf", "html", "rtf", "markdown", "epub", "json"
        ], state="readonly", width=10)
        self.output_format.set("txt")
        self.output_format.pack(side=tk.LEFT, padx=(0, 20))
        
        # Output directory
        ttk.Label(options_row1, text="Output Directory:").pack(side=tk.LEFT, padx=(0, 5))
        self.output_dir = tk.StringVar(value=str(Path.home() / "Documents" / "Converted"))
        ttk.Entry(options_row1, textvariable=self.output_dir, width=30).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(options_row1, text="Browse", command=self.browse_output_dir).pack(side=tk.LEFT)
        
        # Batch processing options
        self.preserve_structure = tk.BooleanVar(value=False)
        ttk.Checkbutton(options_row2, text="Preserve folder structure", variable=self.preserve_structure).pack(side=tk.LEFT, padx=(0, 10))
        
        self.skip_existing = tk.BooleanVar(value=False)
        ttk.Checkbutton(options_row2, text="Skip existing files", variable=self.skip_existing).pack(side=tk.LEFT, padx=(0, 10))
        
        self.use_cache = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_row2, text="Use cache", variable=self.use_cache).pack(side=tk.LEFT, padx=(0, 10))
        
        # Worker threads
        ttk.Label(options_row2, text="Threads:").pack(side=tk.LEFT, padx=(10, 5))
        self.worker_threads = tk.IntVar(value=4)
        ttk.Spinbox(options_row2, from_=1, to=16, textvariable=self.worker_threads, width=5).pack(side=tk.LEFT)
        
        # Processing controls
        control_frame = ttk.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.start_button = ttk.Button(control_frame, text="🚀 Start Conversion", command=self.start_conversion)
        self.start_button.pack(side=tk.LEFT, padx=(0, 10))
        
        self.cancel_button = ttk.Button(control_frame, text="⏹ Cancel", command=self.cancel_conversion, state=tk.DISABLED)
        self.cancel_button.pack(side=tk.LEFT)
        
        # Progress bar and status
        progress_container = ttk.Frame(control_frame)
        progress_container.pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(20, 0))
        
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(progress_container, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.X)
        
        # Progress details
        self.progress_detail_label = ttk.Label(progress_container, text="", font=('Arial', 9))
        self.progress_detail_label.pack(anchor=tk.E)
    
    def create_ocr_tab(self):
        """Create OCR processing tab"""
        ocr_frame = ttk.Frame(self.notebook)
        self.notebook.add(ocr_frame, text="👁 OCR Processing")
        
        if not HAS_OCR:
            ttk.Label(ocr_frame, text="OCR functionality not available. Please install required dependencies.", 
                     font=('Arial', 12)).pack(pady=50)
            return
        
        # OCR Engine Selection
        engine_frame = ttk.LabelFrame(ocr_frame, text="OCR Engine", padding=10)
        engine_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(engine_frame, text="Engine:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        self.ocr_engine_var = ttk.Combobox(engine_frame, values=["auto", "tesseract", "easyocr", "google_vision"], state="readonly")
        self.ocr_engine_var.set("auto")
        self.ocr_engine_var.grid(row=0, column=1, sticky=tk.W, padx=(0, 20))
        self.ocr_engine_var.bind('<<ComboboxSelected>>', self.on_ocr_engine_changed)
        
        ttk.Label(engine_frame, text="Language:").grid(row=0, column=2, sticky=tk.W, padx=(0, 10))
        self.ocr_language = ttk.Combobox(engine_frame, values=[
            "eng", "fra", "deu", "spa", "ita", "por", "eng+fra", "eng+spa", "eng+deu"
        ], state="readonly")
        self.ocr_language.set("eng")
        self.ocr_language.grid(row=0, column=3, sticky=tk.W, padx=(0, 20))
        
        # OCR Quality setting
        ttk.Label(engine_frame, text="Quality:").grid(row=0, column=4, sticky=tk.W, padx=(0, 10))
        self.ocr_quality = ttk.Combobox(engine_frame, values=["fast", "standard", "accurate"], state="readonly")
        self.ocr_quality.set("standard")
        self.ocr_quality.grid(row=0, column=5, sticky=tk.W)
        
        # OCR Engine Status Display
        status_frame = ttk.Frame(engine_frame)
        status_frame.grid(row=1, column=0, columnspan=4, sticky=tk.W, pady=(10, 0))
        
        self.ocr_status_label = ttk.Label(status_frame, text="🔍 OCR Engine: Auto-detect", font=('Arial', 10, 'bold'))
        self.ocr_status_label.pack(anchor=tk.W)
        
        # File selection for batch OCR
        batch_frame = ttk.LabelFrame(ocr_frame, text="Batch OCR Files", padding=10)
        batch_frame.pack(fill=tk.X, pady=(0, 10))
        
        # File list for batch OCR
        list_frame = ttk.Frame(batch_frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        self.ocr_file_listbox = tk.Listbox(list_frame, selectmode=tk.EXTENDED, height=5)
        ocr_scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.ocr_file_listbox.yview)
        self.ocr_file_listbox.configure(yscrollcommand=ocr_scrollbar.set)
        
        self.ocr_file_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        ocr_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Batch file buttons
        batch_btn_frame = ttk.Frame(batch_frame)
        batch_btn_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(batch_btn_frame, text="Add Images", command=self.add_ocr_files).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(batch_btn_frame, text="Add Folder", command=self.add_ocr_folder).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(batch_btn_frame, text="Clear", command=self.clear_ocr_files).pack(side=tk.LEFT)
        
        # OCR Output settings
        output_frame = ttk.Frame(batch_frame)
        output_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Label(output_frame, text="Output Format:").pack(side=tk.LEFT, padx=(0, 5))
        self.ocr_output_format = ttk.Combobox(output_frame, values=["txt", "json", "markdown"], state="readonly", width=10)
        self.ocr_output_format.set("txt")
        self.ocr_output_format.pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Label(output_frame, text="Output Dir:").pack(side=tk.LEFT, padx=(0, 5))
        self.ocr_output_dir = tk.StringVar(value=str(Path.home() / "Documents" / "OCR_Output"))
        ttk.Entry(output_frame, textvariable=self.ocr_output_dir, width=30).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(output_frame, text="Browse", command=self.browse_ocr_output_dir).pack(side=tk.LEFT)
        
        # OCR Preview with drag-drop support
        preview_frame = ttk.LabelFrame(ocr_frame, text="OCR Preview (Drag images here)", padding=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.ocr_preview = scrolledtext.ScrolledText(preview_frame, height=10)
        self.ocr_preview.pack(fill=tk.BOTH, expand=True)
        
        # OCR Controls
        ocr_control_frame = ttk.Frame(ocr_frame)
        ocr_control_frame.pack(fill=tk.X)
        
        ttk.Button(ocr_control_frame, text="📷 Process Single Image", command=self.process_ocr).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(ocr_control_frame, text="📚 Process Batch", command=self.process_batch_ocr).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(ocr_control_frame, text="💾 Save OCR Result", command=self.save_ocr_result).pack(side=tk.LEFT, padx=(0, 10))
        
        # OCR Progress
        self.ocr_progress_var = tk.DoubleVar()
        self.ocr_progress_bar = ttk.Progressbar(ocr_control_frame, variable=self.ocr_progress_var, maximum=100)
        self.ocr_progress_bar.pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(20, 0))
    
    def create_markdown_tab(self):
        """Create bidirectional markdown conversion tab"""
        md_frame = ttk.Frame(self.notebook)
        self.notebook.add(md_frame, text="📝 Markdown Tools")
        
        # Conversion direction
        direction_frame = ttk.LabelFrame(md_frame, text="Conversion Direction", padding=10)
        direction_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.md_direction = tk.StringVar(value="to_markdown")
        ttk.Radiobutton(direction_frame, text="📄 → 📝 Convert TO Markdown", 
                       variable=self.md_direction, value="to_markdown").pack(anchor=tk.W)
        ttk.Radiobutton(direction_frame, text="📝 → 📄 Convert FROM Markdown", 
                       variable=self.md_direction, value="from_markdown").pack(anchor=tk.W)
        
        # Markdown editor/viewer with drag-drop zone
        editor_frame = ttk.LabelFrame(md_frame, text="Markdown Editor/Viewer (Drag files here)", padding=10)
        editor_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create notebook for editor tabs
        self.md_notebook = ttk.Notebook(editor_frame)
        self.md_notebook.pack(fill=tk.BOTH, expand=True)
        
        # Source tab
        source_frame = ttk.Frame(self.md_notebook)
        self.md_notebook.add(source_frame, text="📝 Source")
        self.md_editor = scrolledtext.ScrolledText(source_frame, font=('Consolas', 10))
        self.md_editor.pack(fill=tk.BOTH, expand=True)
        
        # Preview tab
        preview_frame = ttk.Frame(self.md_notebook)
        self.md_notebook.add(preview_frame, text="👁 Preview")
        self.md_preview = scrolledtext.ScrolledText(preview_frame, state=tk.DISABLED)
        self.md_preview.pack(fill=tk.BOTH, expand=True)
        
        # Markdown controls
        md_control_frame = ttk.Frame(md_frame)
        md_control_frame.pack(fill=tk.X)
        
        ttk.Button(md_control_frame, text="📂 Load File", command=self.load_markdown_file).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(md_control_frame, text="💾 Save Markdown", command=self.save_markdown_file).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(md_control_frame, text="🔄 Convert", command=self.convert_markdown).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(md_control_frame, text="👁 Preview", command=self.preview_markdown).pack(side=tk.LEFT)
    
    def create_api_tab(self):
        """Create API management tab"""
        api_frame = ttk.Frame(self.notebook)
        self.notebook.add(api_frame, text="🌐 API Management")
        
        # Google Vision API
        gv_frame = ttk.LabelFrame(api_frame, text="Google Vision API", padding=10)
        gv_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.gv_enabled = tk.BooleanVar(value=self.config.get('api', {}).get('google_vision', {}).get('enabled', False))
        ttk.Checkbutton(gv_frame, text="Enable Google Vision API", variable=self.gv_enabled).pack(anchor=tk.W)
        
        # Fallback settings
        self.gv_fallback_enabled = tk.BooleanVar(value=self.config.get('api', {}).get('google_vision', {}).get('fallback_enabled', True))
        ttk.Checkbutton(gv_frame, text="Auto-fallback to free OCR if API fails", variable=self.gv_fallback_enabled).pack(anchor=tk.W, pady=(5, 0))
        
        # Credentials
        cred_frame = ttk.Frame(gv_frame)
        cred_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Label(cred_frame, text="Credentials File:").pack(anchor=tk.W)
        cred_entry_frame = ttk.Frame(cred_frame)
        cred_entry_frame.pack(fill=tk.X, pady=(5, 0))
        
        self.gv_credentials = tk.StringVar(value=self.config.get('api', {}).get('google_vision', {}).get('credentials_path', ''))
        ttk.Entry(cred_entry_frame, textvariable=self.gv_credentials).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(cred_entry_frame, text="Browse", command=self.browse_credentials).pack(side=tk.RIGHT)
        
        # API testing
        test_frame = ttk.Frame(gv_frame)
        test_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(test_frame, text="🧪 Test Connection", command=self.test_api_connection).pack(side=tk.LEFT, padx=(0, 10))
        self.api_status_label = ttk.Label(test_frame, text="Not tested")
        self.api_status_label.pack(side=tk.LEFT)
        
        # Usage statistics
        stats_frame = ttk.LabelFrame(api_frame, text="API Usage Statistics", padding=10)
        stats_frame.pack(fill=tk.BOTH, expand=True)
        
        self.api_stats = scrolledtext.ScrolledText(stats_frame, height=10, state=tk.DISABLED)
        self.api_stats.pack(fill=tk.BOTH, expand=True)
        
        # Initialize API stats
        self.update_api_stats("API statistics will appear here...")
    
    def create_legacy_tab(self):
        """Create comprehensive VB6/VFP9 DLL integration tab"""
        legacy_frame = ttk.Frame(self.notebook)
        self.notebook.add(legacy_frame, text="🏛 Legacy Integration")
        
        # Create scrollable frame for all content
        canvas = tk.Canvas(legacy_frame)
        scrollbar = ttk.Scrollbar(legacy_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # DLL Status and Builder
        dll_status_frame = ttk.LabelFrame(scrollable_frame, text="32-bit DLL Status", padding=10)
        dll_status_frame.pack(fill=tk.X, pady=(0, 10))
        
        # DLL file status
        dll_status_inner = ttk.Frame(dll_status_frame)
        dll_status_inner.pack(fill=tk.X)
        
        self.dll_status_label = ttk.Label(dll_status_inner, text="⚠️ DLL not built")
        self.dll_status_label.pack(side=tk.LEFT)
        
        ttk.Button(dll_status_inner, text="🔄 Check DLL Status", command=self.check_dll_status).pack(side=tk.RIGHT)
        
        # DLL Builder
        builder_frame = ttk.LabelFrame(scrollable_frame, text="DLL Builder", padding=10)
        builder_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(builder_frame, text="Build the production 32-bit DLL for VB6/VFP9 integration:").pack(anchor=tk.W, pady=(0, 5))
        
        builder_buttons = ttk.Frame(builder_frame)
        builder_buttons.pack(fill=tk.X, pady=(5, 0))
        
        ttk.Button(builder_buttons, text="🔨 Build DLL (Windows)", command=self.build_dll).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(builder_buttons, text="📁 Open DLL Source", command=self.open_dll_source).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(builder_buttons, text="📋 View Build Requirements", command=self.show_build_requirements).pack(side=tk.LEFT)
        
        # VB6 Integration
        vb6_frame = ttk.LabelFrame(scrollable_frame, text="VB6 Integration", padding=10)
        vb6_frame.pack(fill=tk.X, pady=(0, 10))
        
        vb6_buttons = ttk.Frame(vb6_frame)
        vb6_buttons.pack(fill=tk.X)
        
        ttk.Button(vb6_buttons, text="📄 Generate VB6 Module", command=self.generate_vb6_module).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(vb6_buttons, text="🧪 Test VB6 Integration", command=self.test_vb6_integration).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(vb6_buttons, text="📖 VB6 Examples", command=self.show_vb6_examples).pack(side=tk.LEFT)
        
        # VFP9 Integration  
        vfp9_frame = ttk.LabelFrame(scrollable_frame, text="VFP9 Integration", padding=10)
        vfp9_frame.pack(fill=tk.X, pady=(0, 10))
        
        vfp9_buttons = ttk.Frame(vfp9_frame)
        vfp9_buttons.pack(fill=tk.X)
        
        ttk.Button(vfp9_buttons, text="📄 Generate VFP9 Class", command=self.generate_vfp9_class).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(vfp9_buttons, text="🧪 Test VFP9 Integration", command=self.test_vfp9_integration).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(vfp9_buttons, text="📖 VFP9 Examples", command=self.show_vfp9_examples).pack(side=tk.LEFT)
        
        # DLL Testing
        testing_frame = ttk.LabelFrame(scrollable_frame, text="DLL Testing", padding=10)
        testing_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Test file selection
        test_file_frame = ttk.Frame(testing_frame)
        test_file_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(test_file_frame, text="Test File:").pack(side=tk.LEFT)
        self.test_file_path = tk.StringVar()
        ttk.Entry(test_file_frame, textvariable=self.test_file_path, width=40).pack(side=tk.LEFT, padx=(10, 5), fill=tk.X, expand=True)
        ttk.Button(test_file_frame, text="📁 Browse", command=self.browse_test_file).pack(side=tk.RIGHT)
        
        # Test conversion
        test_buttons = ttk.Frame(testing_frame)
        test_buttons.pack(fill=tk.X, pady=(5, 0))
        
        ttk.Button(test_buttons, text="🧪 Test DLL Conversion", command=self.test_dll_conversion).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(test_buttons, text="🔍 Test DLL Functions", command=self.test_dll_functions).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(test_buttons, text="📊 Performance Test", command=self.performance_test_dll).pack(side=tk.LEFT)
        
        # Installation and Deployment
        deploy_frame = ttk.LabelFrame(scrollable_frame, text="Installation & Deployment", padding=10)
        deploy_frame.pack(fill=tk.X, pady=(0, 10))
        
        deploy_buttons = ttk.Frame(deploy_frame)
        deploy_buttons.pack(fill=tk.X)
        
        ttk.Button(deploy_buttons, text="📦 Create Distribution Package", command=self.create_dll_package).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(deploy_buttons, text="⚙️ Install DLL System-wide", command=self.install_dll_system).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(deploy_buttons, text="📋 Copy Integration Files", command=self.copy_integration_files).pack(side=tk.LEFT)
        
        # Output and Logs
        output_frame = ttk.LabelFrame(scrollable_frame, text="Output & Logs", padding=10)
        output_frame.pack(fill=tk.BOTH, expand=True)
        
        self.legacy_output = scrolledtext.ScrolledText(output_frame, height=12, font=('Consolas', 9))
        self.legacy_output.pack(fill=tk.BOTH, expand=True)
        
        # Initialize DLL status check
        self.check_dll_status()
    
    def create_tools_tab(self):
        """Create tools tab with thread selector, memory, and security features"""
        tools_frame = ttk.Frame(self.notebook)
        self.notebook.add(tools_frame, text="🛠️ Tools")
        
        # Thread Management
        thread_frame = ttk.LabelFrame(tools_frame, text="Thread Management", padding=10)
        thread_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(thread_frame, text="Active Threads:").grid(row=0, column=0, sticky=tk.W)
        self.thread_count_label = ttk.Label(thread_frame, text=str(threading.active_count()))
        self.thread_count_label.grid(row=0, column=1, sticky=tk.W, padx=(10, 0))
        
        ttk.Button(thread_frame, text="Refresh", command=self.refresh_thread_info).grid(row=0, column=2, padx=(20, 0))
        
        # Thread list
        self.thread_listbox = tk.Listbox(thread_frame, height=5)
        self.thread_listbox.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(10, 0))
        thread_scrollbar = ttk.Scrollbar(thread_frame, orient=tk.VERTICAL, command=self.thread_listbox.yview)
        thread_scrollbar.grid(row=1, column=3, sticky=(tk.N, tk.S), pady=(10, 0))
        self.thread_listbox.configure(yscrollcommand=thread_scrollbar.set)
        
        # Memory Management
        memory_frame = ttk.LabelFrame(tools_frame, text="Memory Usage", padding=10)
        memory_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.memory_info_text = tk.Text(memory_frame, height=6, width=50)
        self.memory_info_text.pack(fill=tk.X)
        
        button_frame = ttk.Frame(memory_frame)
        button_frame.pack(pady=(10, 0))
        
        ttk.Button(button_frame, text="Update Memory Info", command=self.update_memory_info).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="Optimize Memory", command=self.optimize_memory).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="Clear Cache", command=lambda: [self.clear_cache(), self.update_memory_info()]).pack(side=tk.LEFT)
        
        # Security Settings
        security_frame = ttk.LabelFrame(tools_frame, text="Security", padding=10)
        security_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.secure_mode = tk.BooleanVar(value=True)
        ttk.Checkbutton(security_frame, text="Enable secure file path validation", variable=self.secure_mode).pack(anchor=tk.W)
        
        self.sandbox_mode = tk.BooleanVar(value=False)
        ttk.Checkbutton(security_frame, text="Sandbox mode (restrict file access)", variable=self.sandbox_mode).pack(anchor=tk.W)
        
        ttk.Label(security_frame, text="Allowed directories (one per line):").pack(anchor=tk.W, pady=(10, 5))
        self.allowed_dirs_text = tk.Text(security_frame, height=4, width=50)
        self.allowed_dirs_text.pack(fill=tk.X)
        self.allowed_dirs_text.insert(tk.END, str(Path.home() / "Documents"))
        
        # Initialize tools info
        self.refresh_thread_info()
        self.update_memory_info()
    
    def create_settings_tab(self):
        """Create comprehensive settings tab"""
        settings_frame = ttk.Frame(self.notebook)
        self.notebook.add(settings_frame, text="⚙️ Settings")
        
        # Create settings notebook
        settings_notebook = ttk.Notebook(settings_frame)
        settings_notebook.pack(fill=tk.BOTH, expand=True)
        
        # General settings
        general_frame = ttk.Frame(settings_notebook)
        settings_notebook.add(general_frame, text="General")
        
        # Performance settings
        perf_frame = ttk.Frame(settings_notebook)
        settings_notebook.add(perf_frame, text="Performance")
        
        # Logging settings
        log_frame = ttk.Frame(settings_notebook)
        settings_notebook.add(log_frame, text="Logging")
        
        # Setup each settings section
        self.setup_general_settings(general_frame)
        self.setup_performance_settings(perf_frame)
        self.setup_logging_settings(log_frame)
        
        # Settings controls
        settings_control_frame = ttk.Frame(settings_frame)
        settings_control_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(settings_control_frame, text="💾 Save Settings", command=self.save_settings).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(settings_control_frame, text="🔄 Reset to Defaults", command=self.reset_settings).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(settings_control_frame, text="📂 Open Config Folder", command=self.open_config_folder).pack(side=tk.LEFT)
    
    def setup_general_settings(self, parent):
        """Setup general settings section"""
        # Theme selection
        theme_frame = ttk.LabelFrame(parent, text="Appearance", padding=10)
        theme_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(theme_frame, text="Theme:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        self.theme_var = ttk.Combobox(theme_frame, values=["default", "clam", "alt", "classic"], state="readonly")
        self.theme_var.set(self.config.get('gui', {}).get('theme', 'default'))
        self.theme_var.grid(row=0, column=1, sticky=tk.W)
        
        # File handling
        file_frame = ttk.LabelFrame(parent, text="File Handling", padding=10)
        file_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.preserve_formatting = tk.BooleanVar(value=self.config.get('conversion', {}).get('preserve_formatting', True))
        ttk.Checkbutton(file_frame, text="Preserve formatting during conversion", variable=self.preserve_formatting).pack(anchor=tk.W)
        
        self.auto_preview = tk.BooleanVar(value=self.config.get('gui', {}).get('auto_preview', False))
        ttk.Checkbutton(file_frame, text="Auto-preview converted files", variable=self.auto_preview).pack(anchor=tk.W)
    
    def setup_performance_settings(self, parent):
        """Setup performance settings section"""
        # Threading
        thread_frame = ttk.LabelFrame(parent, text="Threading", padding=10)
        thread_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(thread_frame, text="Max Workers:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        self.max_workers = tk.IntVar(value=self.config.get('conversion', {}).get('max_workers', 4))
        ttk.Spinbox(thread_frame, from_=1, to=16, textvariable=self.max_workers, width=5).grid(row=0, column=1, sticky=tk.W)
        
        # Caching
        cache_frame = ttk.LabelFrame(parent, text="Caching", padding=10)
        cache_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.ocr_use_cache = tk.BooleanVar(value=self.config.get('ocr', {}).get('use_cache', True))
        ttk.Checkbutton(cache_frame, text="Enable OCR result caching", variable=self.ocr_use_cache).pack(anchor=tk.W)
        
        ttk.Button(cache_frame, text="Clear Cache", command=self.clear_cache).pack(anchor=tk.W, pady=(10, 0))
    
    def setup_logging_settings(self, parent):
        """Setup logging settings section"""
        # Log level
        level_frame = ttk.LabelFrame(parent, text="Log Level", padding=10)
        level_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(level_frame, text="Level:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        self.log_level = ttk.Combobox(level_frame, values=["DEBUG", "INFO", "WARNING", "ERROR"], state="readonly")
        self.log_level.set(self.config.get('logging', {}).get('level', 'INFO'))
        self.log_level.grid(row=0, column=1, sticky=tk.W)
    
    def create_status_bar(self, parent):
        """Create status bar at bottom"""
        status_frame = ttk.Frame(parent)
        status_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.status_label = ttk.Label(status_frame, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Version label
        version_label = ttk.Label(status_frame, text="v3.1.0", relief=tk.SUNKEN)
        version_label.pack(side=tk.RIGHT)
    
    def setup_drag_drop(self):
        """Setup drag and drop functionality for all tabs"""
        try:
            from tkinterdnd2 import DND_FILES, TkinterDnD
            # Enable drag and drop on file listbox
            self.file_listbox.drop_target_register(DND_FILES)
            self.file_listbox.dnd_bind('<<Drop>>', self.on_drop)
            
            # Enable drag and drop on OCR preview and file list
            if hasattr(self, 'ocr_preview'):
                self.ocr_preview.drop_target_register(DND_FILES)
                self.ocr_preview.dnd_bind('<<Drop>>', self.on_ocr_drop)
            
            if hasattr(self, 'ocr_file_listbox'):
                self.ocr_file_listbox.drop_target_register(DND_FILES)
                self.ocr_file_listbox.dnd_bind('<<Drop>>', self.on_ocr_drop)
            
            # Enable drag and drop on markdown editor
            if hasattr(self, 'md_editor'):
                self.md_editor.drop_target_register(DND_FILES)
                self.md_editor.dnd_bind('<<Drop>>', self.on_markdown_drop)
        except ImportError:
            self.logger.warning("Drag and drop not available - tkinterdnd2 not installed")
    
    def on_drop(self, event):
        """Handle dropped files"""
        files = self.file_listbox.tk.splitlist(event.data)
        for file_path in files:
            if Path(file_path).is_file():
                # Validate file path for security
                if HAS_OCR:
                    try:
                        validate_file_path(file_path)
                        self.file_listbox.insert(tk.END, file_path)
                    except SecurityError as e:
                        self.logger.warning(f"Security validation failed for {file_path}: {e}")
                        messagebox.showwarning("Security Warning", f"Cannot add file: {e}")
                else:
                    self.file_listbox.insert(tk.END, file_path)
    
    def on_ocr_drop(self, event):
        """Handle dropped images for OCR"""
        files = self.ocr_preview.tk.splitlist(event.data)
        for file_path in files:
            if Path(file_path).is_file():
                # Check if it's an image file
                if file_path.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.gif')):
                    # Add to batch list
                    self.ocr_file_listbox.insert(tk.END, file_path)
                    # Process first image for preview
                    if self.ocr_file_listbox.size() == 1:
                        self.process_ocr_file(file_path)
    
    def on_markdown_drop(self, event):
        """Handle dropped files for markdown conversion"""
        files = self.md_editor.tk.splitlist(event.data)
        for file_path in files:
            if Path(file_path).is_file():
                # Check file type and convert
                if file_path.lower().endswith(('.docx', '.pdf')):
                    self.convert_dropped_to_markdown(file_path)
                    break  # Only process first file
    
    # File management methods
    def add_files(self):
        """Add files to conversion list"""
        files = filedialog.askopenfilenames(
            title="Select files to convert",
            filetypes=[
                ("All supported", "*.txt;*.docx;*.pdf;*.html;*.rtf;*.md;*.epub"),
                ("Text files", "*.txt"),
                ("Word documents", "*.docx"),
                ("PDF files", "*.pdf"),
                ("HTML files", "*.html"),
                ("RTF files", "*.rtf"),
                ("Markdown files", "*.md"),
                ("EPUB files", "*.epub")
            ]
        )
        for file in files:
            self.file_listbox.insert(tk.END, file)
    
    def add_folder(self):
        """Add folder for batch conversion"""
        folder = filedialog.askdirectory(title="Select folder to convert")
        if folder:
            folder_path = Path(folder)
            for file_path in folder_path.rglob("*"):
                if file_path.is_file() and file_path.suffix.lower() in ['.txt', '.docx', '.pdf', '.html', '.rtf', '.md', '.epub']:
                    self.file_listbox.insert(tk.END, str(file_path))
    
    def clear_files(self):
        """Clear file list"""
        self.file_listbox.delete(0, tk.END)
    
    def browse_output_dir(self):
        """Browse for output directory"""
        directory = filedialog.askdirectory(title="Select output directory")
        if directory:
            self.output_dir.set(directory)
    
    # Conversion methods
    def start_conversion(self):
        """Start document conversion process"""
        if self.is_processing:
            return
        
        files = list(self.file_listbox.get(0, tk.END))
        if not files:
            messagebox.showwarning("No Files", "Please add files to convert first.")
            return
        
        output_dir = Path(self.output_dir.get())
        output_dir.mkdir(parents=True, exist_ok=True)
        
        self.is_processing = True
        self.cancel_processing = False
        self.processed_count = 0
        self.total_files = len(files)
        
        self.start_button.config(state=tk.DISABLED)
        self.cancel_button.config(state=tk.NORMAL)
        
        # Start conversion in separate thread
        self.processing_thread = threading.Thread(target=self.conversion_worker, args=(files, output_dir))
        self.processing_thread.daemon = True
        self.processing_thread.start()
    
    def conversion_worker(self, files, output_dir):
        """Worker thread for file conversion with concurrent processing"""
        try:
            self.start_time = time.time()
            max_workers = self.worker_threads.get()
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                # Submit all conversion tasks
                futures = {}
                for i, file_path in enumerate(files):
                    if self.cancel_processing:
                        break
                    
                    future = executor.submit(self.convert_single_file_safe, file_path, output_dir, i)
                    futures[future] = file_path
                
                # Process completed futures
                for future in concurrent.futures.as_completed(futures):
                    if self.cancel_processing:
                        executor.shutdown(wait=False)
                        break
                    
                    file_path = futures[future]
                    try:
                        success, status = future.result()
                        if success:
                            if status == 'converted':
                                self.processed_count += 1
                            elif status == 'skipped':
                                self.skipped_count += 1
                        else:
                            self.failed_count += 1
                    except Exception as e:
                        self.logger.error(f"Error processing {file_path}: {e}")
                        self.failed_count += 1
                    
                    # Update progress with ETA
                    completed = self.processed_count + self.failed_count + self.skipped_count
                    progress = (completed / len(files)) * 100
                    self.update_progress_with_eta(progress, completed, len(files))
        
        finally:
            self.root.after(0, self.processing_complete)
    
    def convert_single_file_safe(self, file_path, output_dir, index):
        """Thread-safe wrapper for single file conversion"""
        try:
            self.update_status(f"Processing {Path(file_path).name}...")
            return self.convert_single_file(file_path, output_dir)
        except Exception as e:
            self.logger.error(f"Error converting {file_path}: {e}")
            return False, 'error'
    
    def convert_single_file(self, input_path, output_dir):
        """Convert a single file with caching and skip support"""
        input_file = Path(input_path)
        output_format = self.output_format.get()
        
        # Handle preserve structure option
        if self.preserve_structure.get():
            # Calculate relative path from base directory
            try:
                base_dir = Path(self.file_listbox.get(0)).parent
                rel_path = input_file.relative_to(base_dir).parent
                output_subdir = output_dir / rel_path
                output_subdir.mkdir(parents=True, exist_ok=True)
            except (ValueError, AttributeError) as e:
                self.logger.debug(f"Could not determine relative path: {e}")
                output_subdir = output_dir
        else:
            output_subdir = output_dir
        
        # Determine output filename
        output_file = output_subdir / f"{input_file.stem}.{output_format}"
        
        # Skip existing files if option is enabled
        if self.skip_existing.get() and output_file.exists():
            self.logger.info(f"Skipping existing file: {output_file}")
            return True, 'skipped'
        
        # Check cache
        cache_key = None
        if self.use_cache.get():
            cache_key = self.get_cache_key(input_path, output_format)
            cached_result = self.get_cached_result(cache_key)
            if cached_result:
                # Write cached result
                with open(output_file, 'wb') as f:
                    f.write(cached_result)
                self.logger.info(f"Using cached result for {input_file.name}")
                return True, 'converted'
        
        # Perform conversion based on format
        if output_format == "markdown" and HAS_MARKDOWN:
            if input_file.suffix.lower() == '.docx':
                convert_docx_to_markdown(str(input_file))
                # Move the generated markdown file to output directory
                md_file = input_file.with_suffix('.md')
                if md_file.exists():
                    shutil.move(str(md_file), str(output_file))
            elif input_file.suffix.lower() == '.pdf':
                convert_pdf_to_markdown(str(input_file))
                # Move the generated markdown file to output directory
                md_file = input_file.with_suffix('.md')
                if md_file.exists():
                    shutil.move(str(md_file), str(output_file))
        else:
            # Basic conversion (placeholder - would need full implementation)
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(f"Converted from: {input_path}\n")
                f.write(f"Format: {output_format}\n")
                f.write("Full conversion implementation would go here.\n")
        
        # Cache result if enabled
        if cache_key and output_file.exists():
            try:
                with open(output_file, 'rb') as f:
                    content = f.read()
                    self.cache_result(cache_key, content)
            except (IOError, OSError) as e:
                self.logger.debug(f"Could not cache result: {e}")
                pass
        
        return True, 'converted'
    
    def cancel_conversion(self):
        """Cancel ongoing conversion"""
        self.cancel_processing = True
        self.update_status("Cancelling...")
    
    def processing_complete(self):
        """Handle conversion completion"""
        self.is_processing = False
        self.start_button.config(state=tk.NORMAL)
        self.cancel_button.config(state=tk.DISABLED)
        
        # Calculate final statistics
        total_processed = self.processed_count + self.failed_count + self.skipped_count
        elapsed_time = time.time() - self.start_time if self.start_time else 0
        
        # Build status message
        status_parts = [f"{self.processed_count} converted"]
        if self.skipped_count > 0:
            status_parts.append(f"{self.skipped_count} skipped")
        if self.failed_count > 0:
            status_parts.append(f"{self.failed_count} failed")
        
        status_msg = f"Complete - {', '.join(status_parts)}"
        
        if elapsed_time > 0:
            if elapsed_time < 60:
                time_str = f"{elapsed_time:.1f} seconds"
            else:
                time_str = f"{int(elapsed_time / 60)} minutes {int(elapsed_time % 60)} seconds"
            status_msg += f" in {time_str}"
        
        if self.cancel_processing:
            status_msg = f"Cancelled - {status_msg}"
        
        self.update_status(status_msg)
        
        if not self.cancel_processing:
            # Show detailed completion dialog
            detail_msg = f"""Conversion completed!

Processed: {self.processed_count} files
Skipped: {self.skipped_count} files
Failed: {self.failed_count} files
Total time: {time_str if elapsed_time > 0 else 'N/A'}

Output directory: {self.output_dir.get()}"""
            messagebox.showinfo("Conversion Complete", detail_msg)
        
        # Reset counters
        self.processed_count = 0
        self.failed_count = 0
        self.skipped_count = 0
        self.start_time = None
        self.update_progress(0)
        self.progress_detail_label.config(text="")
    
    # OCR methods
    def on_ocr_engine_changed(self, event=None):
        """Handle OCR engine selection change"""
        engine = self.ocr_engine_var.get()
        if engine == "auto":
            self.ocr_status_label.config(text="🔍 OCR Engine: Auto-detect")
        elif engine == "tesseract":
            self.ocr_status_label.config(text="🆓 OCR Engine: Tesseract (Free)")
        elif engine == "easyocr":
            self.ocr_status_label.config(text="🆓 OCR Engine: EasyOCR (Free)")
        elif engine == "google_vision":
            if self.gv_enabled.get():
                self.ocr_status_label.config(text="☁️ OCR Engine: Google Vision API")
            else:
                self.ocr_status_label.config(text="⚠️ Google Vision API not enabled")
                self.ocr_engine_var.set("auto")
                messagebox.showwarning("API Not Enabled", "Please enable Google Vision API in the API Management tab first.")
    
    def process_ocr(self):
        """Process OCR on selected image"""
        file_path = filedialog.askopenfilename(
            title="Select image for OCR",
            filetypes=[
                ("Image files", "*.png;*.jpg;*.jpeg;*.tiff;*.bmp;*.gif"),
                ("All files", "*.*")
            ]
        )
        
        if not file_path:
            return
        
        self.process_ocr_file(file_path)
    
    def process_ocr_file(self, file_path):
        """Process OCR on a specific file"""
        
        if not self.ocr_engine:
            messagebox.showerror("OCR Error", "OCR engine not available")
            return
        
        try:
            # Validate file path for security
            if HAS_OCR:
                validate_file_path(file_path)
            
            self.update_status("Processing OCR...")
            
            # Get OCR settings
            engine = self.ocr_engine_var.get()
            quality = self.ocr_quality.get()
            
            # Set quality-based options
            confidence_threshold = {'fast': 0.5, 'standard': 0.7, 'accurate': 0.85}.get(quality, 0.7)
            preprocess = quality == 'accurate'
            
            options = {
                'engine': engine,
                'language': self.ocr_language.get(),
                'confidence_threshold': confidence_threshold,
                'preprocess': preprocess
            }
            
            # Update status to show which engine is being used
            if engine == "google_vision" and self.gv_enabled.get():
                self.update_status("Processing with Google Vision API...")
            elif engine in ["tesseract", "easyocr"]:
                self.update_status(f"Processing with {engine.title()} (Free)...")
            else:
                self.update_status("Processing with auto-detected engine...")
            
            # Process OCR with fallback
            result = self.process_ocr_with_fallback(file_path, options)
            
            # Display result
            self.ocr_preview.delete(1.0, tk.END)
            self.ocr_preview.insert(tk.END, result.get('text', 'No text detected'))
            
            # Update status with engine used
            engine_used = result.get('engine_used', engine)
            confidence = result.get('confidence', 'N/A')
            fallback_used = result.get('fallback_used', False)
            
            if fallback_used:
                self.update_status(f"OCR completed ({engine_used.title()} - Free, API fallback) - Confidence: {confidence}")
                self.logger.warning(f"API failed, used fallback engine: {engine_used}")
            elif engine_used == "google_vision":
                self.update_status(f"OCR completed (Google Vision API) - Confidence: {confidence}")
            else:
                self.update_status(f"OCR completed ({engine_used.title()} - Free) - Confidence: {confidence}")
            
        except Exception as e:
            messagebox.showerror("OCR Error", f"OCR processing failed: {e}")
            self.update_status("OCR failed")
    
    def add_ocr_files(self):
        """Add image files for OCR processing"""
        files = filedialog.askopenfilenames(
            title="Select images for OCR",
            filetypes=[
                ("Image files", "*.png;*.jpg;*.jpeg;*.tiff;*.bmp;*.gif"),
                ("All files", "*.*")
            ]
        )
        for file in files:
            self.ocr_file_listbox.insert(tk.END, file)
    
    def add_ocr_folder(self):
        """Add folder of images for OCR processing"""
        folder = filedialog.askdirectory(title="Select folder with images")
        if folder:
            folder_path = Path(folder)
            for file_path in folder_path.rglob("*"):
                if file_path.is_file() and file_path.suffix.lower() in ['.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.gif']:
                    self.ocr_file_listbox.insert(tk.END, str(file_path))
    
    def clear_ocr_files(self):
        """Clear OCR file list"""
        self.ocr_file_listbox.delete(0, tk.END)
    
    def browse_ocr_output_dir(self):
        """Browse for OCR output directory"""
        directory = filedialog.askdirectory(title="Select OCR output directory")
        if directory:
            self.ocr_output_dir.set(directory)
    
    def process_batch_ocr(self):
        """Process batch OCR on multiple files"""
        files = list(self.ocr_file_listbox.get(0, tk.END))
        if not files:
            messagebox.showwarning("No Files", "Please add image files for OCR processing.")
            return
        
        if not self.ocr_engine:
            messagebox.showerror("OCR Error", "OCR engine not available")
            return
        
        # Create output directory
        output_dir = Path(self.ocr_output_dir.get())
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Start batch processing in thread
        self.ocr_progress_var.set(0)
        threading.Thread(target=self.batch_ocr_worker, args=(files, output_dir), daemon=True).start()
    
    def batch_ocr_worker(self, files, output_dir):
        """Worker thread for batch OCR processing"""
        total_files = len(files)
        processed = 0
        failed = 0
        
        self.update_status(f"Processing {total_files} images for OCR...")
        
        for i, file_path in enumerate(files):
            try:
                # Process OCR
                result = self.process_ocr_file_batch(file_path)
                
                if result:
                    # Save result based on format
                    output_format = self.ocr_output_format.get()
                    input_name = Path(file_path).stem
                    output_file = output_dir / f"{input_name}.{output_format}"
                    
                    if output_format == "json":
                        import json
                        with open(output_file, 'w', encoding='utf-8') as f:
                            json.dump(result, f, indent=2)
                    elif output_format == "markdown":
                        with open(output_file, 'w', encoding='utf-8') as f:
                            f.write(f"# OCR Result: {input_name}\n\n")
                            f.write(result.get('text', ''))
                            f.write(f"\n\n*Confidence: {result.get('confidence', 'N/A')}*")
                    else:  # txt
                        with open(output_file, 'w', encoding='utf-8') as f:
                            f.write(result.get('text', ''))
                    
                    processed += 1
                else:
                    failed += 1
                    
            except Exception as e:
                self.logger.error(f"Batch OCR error for {file_path}: {e}")
                failed += 1
            
            # Update progress
            progress = ((i + 1) / total_files) * 100
            self.root.after(0, lambda p=progress: self.ocr_progress_var.set(p))
        
        # Show completion
        self.update_status(f"Batch OCR complete - {processed} successful, {failed} failed")
        self.root.after(0, lambda: messagebox.showinfo(
            "Batch OCR Complete", 
            f"Processed {total_files} images\n{processed} successful\n{failed} failed\n\nOutput: {output_dir}"
        ))
    
    def process_ocr_file_batch(self, file_path):
        """Process OCR for batch operation"""
        try:
            # Get OCR settings
            engine = self.ocr_engine_var.get()
            quality = self.ocr_quality.get()
            
            # Set quality-based options
            confidence_threshold = {'fast': 0.5, 'standard': 0.7, 'accurate': 0.85}.get(quality, 0.7)
            preprocess = quality == 'accurate'
            
            options = {
                'engine': engine,
                'language': self.ocr_language.get(),
                'confidence_threshold': confidence_threshold,
                'preprocess': preprocess
            }
            
            # Process OCR with fallback
            return self.process_ocr_with_fallback(file_path, options)
            
        except Exception as e:
            self.logger.error(f"OCR error for {file_path}: {e}")
            return None
    
    def save_ocr_result(self):
        """Save OCR result to file"""
        text = self.ocr_preview.get(1.0, tk.END).strip()
        if not text:
            messagebox.showwarning("No Text", "No OCR text to save")
            return
        
        output_format = self.ocr_output_format.get()
        ext = f".{output_format}"
        
        file_path = filedialog.asksaveasfilename(
            title="Save OCR result",
            defaultextension=ext,
            filetypes=[
                ("Text files", "*.txt"),
                ("JSON files", "*.json"),
                ("Markdown files", "*.md"),
                ("All files", "*.*")
            ]
        )
        
        if file_path:
            try:
                if output_format == "json":
                    import json
                    data = {"text": text, "timestamp": datetime.datetime.now().isoformat()}
                    with open(file_path, 'w', encoding='utf-8') as f:
                        json.dump(data, f, indent=2)
                elif output_format == "markdown":
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(f"# OCR Result\n\n{text}\n\n*Generated: {datetime.datetime.now()}*")
                else:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(text)
                messagebox.showinfo("Saved", f"OCR result saved to {file_path}")
            except Exception as e:
                messagebox.showerror("Save Error", f"Could not save file: {e}")
    
    # Markdown methods
    def load_markdown_file(self):
        """Load markdown file into editor"""
        file_path = filedialog.askopenfilename(
            title="Load markdown file",
            filetypes=[("Markdown files", "*.md"), ("Text files", "*.txt"), ("All files", "*.*")]
        )
        
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                self.md_editor.delete(1.0, tk.END)
                self.md_editor.insert(tk.END, content)
            except Exception as e:
                messagebox.showerror("Load Error", f"Could not load file: {e}")
    
    def save_markdown_file(self):
        """Save markdown from editor"""
        content = self.md_editor.get(1.0, tk.END)
        if not content.strip():
            messagebox.showwarning("No Content", "No content to save")
            return
        
        file_path = filedialog.asksaveasfilename(
            title="Save markdown file",
            defaultextension=".md",
            filetypes=[("Markdown files", "*.md"), ("Text files", "*.txt"), ("All files", "*.*")]
        )
        
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                messagebox.showinfo("Saved", f"Markdown saved to {file_path}")
            except Exception as e:
                messagebox.showerror("Save Error", f"Could not save file: {e}")
    
    def convert_dropped_to_markdown(self, file_path):
        """Convert a dropped file to markdown"""
        if HAS_MARKDOWN:
            try:
                self.update_status(f"Converting {Path(file_path).name} to markdown...")
                
                # Read the actual content after conversion
                output_path = None
                if file_path.endswith('.docx'):
                    convert_docx_to_markdown(file_path)
                    output_path = Path(file_path).with_suffix('.md')
                elif file_path.endswith('.pdf'):
                    convert_pdf_to_markdown(file_path)
                    output_path = Path(file_path).with_suffix('.md')
                
                # Load the converted content
                if output_path and output_path.exists():
                    with open(output_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    self.md_editor.delete(1.0, tk.END)
                    self.md_editor.insert(tk.END, content)
                    self.update_status(f"Converted {Path(file_path).name} to markdown")
                else:
                    self.update_status("Conversion completed but output file not found")
                    
            except Exception as e:
                messagebox.showerror("Conversion Error", f"Could not convert: {e}")
                self.update_status("Conversion failed")
    
    def convert_markdown(self):
        """Convert markdown bidirectionally"""
        direction = self.md_direction.get()
        
        if direction == "to_markdown":
            # Convert TO markdown
            file_path = filedialog.askopenfilename(
                title="Select file to convert to markdown",
                filetypes=[("Word documents", "*.docx"), ("PDF files", "*.pdf"), ("All files", "*.*")]
            )
            
            if file_path:
                self.convert_dropped_to_markdown(file_path)
        else:
            # Convert FROM markdown
            messagebox.showinfo("Coming Soon", "Conversion FROM markdown will be implemented in a future version")
    
    def preview_markdown(self):
        """Preview markdown content"""
        content = self.md_editor.get(1.0, tk.END)
        # Simple preview (would need markdown renderer for full preview)
        self.md_preview.config(state=tk.NORMAL)
        self.md_preview.delete(1.0, tk.END)
        self.md_preview.insert(tk.END, f"Markdown Preview:\n\n{content}")
        self.md_preview.config(state=tk.DISABLED)
    
    # API methods
    def browse_credentials(self):
        """Browse for Google Vision API credentials"""
        file_path = filedialog.askopenfilename(
            title="Select Google Vision API credentials",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        
        if file_path:
            self.gv_credentials.set(file_path)
    
    def test_api_connection(self):
        """Test Google Vision API connection"""
        if not HAS_GOOGLE_VISION:
            self.api_status_label.config(text="❌ Google Vision not available")
            if self.gv_fallback_enabled.get():
                self.api_status_label.config(text="❌ Google Vision not available (fallback enabled)")
            return
        
        credentials_path = self.gv_credentials.get()
        if not credentials_path:
            self.api_status_label.config(text="❌ No credentials file")
            if self.gv_fallback_enabled.get():
                self.api_status_label.config(text="❌ No credentials file (fallback enabled)")
            return
        
        try:
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials_path
            client = vision.ImageAnnotatorClient()
            self.api_status_label.config(text="✅ Connection successful")
            
            # Update API stats
            self.update_api_stats("Connection test successful")
        except Exception as e:
            if self.gv_fallback_enabled.get():
                self.api_status_label.config(text=f"❌ Connection failed (fallback enabled): {str(e)[:30]}...")
            else:
                self.api_status_label.config(text=f"❌ Connection failed: {str(e)[:30]}...")
            
            # Update API stats
            self.update_api_stats(f"Connection test failed: {str(e)}")
    
    # Legacy integration methods
    def test_cli_command(self):
        """Test CLI command for VB6/VFP9 integration"""
        command = self.cli_command.get()
        
        try:
            # Parse command safely - split into args
            import shlex
            args = shlex.split(command)
            result = subprocess.run(args, capture_output=True, text=True, timeout=30)
            
            self.cli_output.delete(1.0, tk.END)
            self.cli_output.insert(tk.END, f"Command: {command}\n")
            self.cli_output.insert(tk.END, f"Return code: {result.returncode}\n\n")
            self.cli_output.insert(tk.END, "STDOUT:\n")
            self.cli_output.insert(tk.END, result.stdout)
            self.cli_output.insert(tk.END, "\nSTDERR:\n")
            self.cli_output.insert(tk.END, result.stderr)
            
        except subprocess.TimeoutExpired:
            self.cli_output.delete(1.0, tk.END)
            self.cli_output.insert(tk.END, "Command timed out after 30 seconds")
        except Exception as e:
            self.cli_output.delete(1.0, tk.END)
            self.cli_output.insert(tk.END, f"Error running command: {e}")
    
    # === DLL INTEGRATION METHODS ===
    
    def check_dll_status(self):
        """Check the status of the DLL build and installation"""
        self.legacy_log("Checking DLL status...")
        
        # Check for built DLL
        dll_paths = [
            Path("dist/UniversalConverter32.dll"),
            Path("dll_source/UniversalConverter32.dll"),
            Path("UniversalConverter32.dll")
        ]
        
        dll_found = False
        dll_path = None
        
        for path in dll_paths:
            if path.exists():
                dll_found = True
                dll_path = path
                break
        
        if dll_found:
            self.dll_status_label.config(text=f"✅ DLL found: {dll_path}")
            self.legacy_log(f"✅ DLL found at: {dll_path}")
            
            # Check DLL file size and modification time
            stat = dll_path.stat()
            size_kb = stat.st_size / 1024
            mod_time = datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
            self.legacy_log(f"   Size: {size_kb:.1f} KB, Modified: {mod_time}")
        else:
            self.dll_status_label.config(text="⚠️ DLL not built")
            self.legacy_log("⚠️ DLL not found - use 'Build DLL' to create it")
        
        # Check for source files
        source_files = [
            "dll_source/UniversalConverter32.cpp",
            "dll_source/UniversalConverter32.def",
            "build_dll.bat"
        ]
        
        for file in source_files:
            if Path(file).exists():
                self.legacy_log(f"✅ Source: {file}")
            else:
                self.legacy_log(f"❌ Missing: {file}")
    
    def build_dll(self):
        """Build the 32-bit DLL using the build script"""
        self.legacy_log("Building UniversalConverter32.dll...")
        
        try:
            # Check if on Windows
            import platform
            if platform.system() != "Windows":
                self.legacy_log("❌ DLL building requires Windows")
                self.legacy_log("   Transfer files to Windows system and run build_dll.bat")
                return
            
            # Check for build script
            build_script = Path("build_dll.bat")
            if not build_script.exists():
                self.legacy_log("❌ build_dll.bat not found")
                return
            
            # Run build script in a separate thread
            def build_thread():
                try:
                    import subprocess
                    process = subprocess.Popen(
                        ["build_dll.bat"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        universal_newlines=True
                    )
                    
                    # Read output line by line
                    for line in process.stdout:
                        self.legacy_log(line.strip())
                    
                    process.wait()
                    
                    if process.returncode == 0:
                        self.legacy_log("✅ DLL build completed successfully!")
                        self.check_dll_status()  # Refresh status
                    else:
                        self.legacy_log(f"❌ DLL build failed with code {process.returncode}")
                        
                except Exception as e:
                    self.legacy_log(f"❌ Build error: {str(e)}")
            
            # Start build in background
            import threading
            threading.Thread(target=build_thread, daemon=True).start()
            
        except Exception as e:
            self.legacy_log(f"❌ Error starting build: {str(e)}")
    
    def open_dll_source(self):
        """Open the DLL source directory"""
        try:
            source_dir = Path("dll_source")
            if source_dir.exists():
                import subprocess
                import platform
                
                if platform.system() == "Windows":
                    subprocess.Popen(f'explorer "{source_dir.absolute()}"')
                elif platform.system() == "Darwin":  # macOS
                    subprocess.Popen(["open", str(source_dir.absolute())])
                else:  # Linux
                    subprocess.Popen(["xdg-open", str(source_dir.absolute())])
                
                self.legacy_log(f"📁 Opened source directory: {source_dir.absolute()}")
            else:
                self.legacy_log("❌ DLL source directory not found")
        except Exception as e:
            self.legacy_log(f"❌ Error opening directory: {str(e)}")
    
    def show_build_requirements(self):
        """Show DLL build requirements"""
        requirements = """
DLL Build Requirements:

SYSTEM REQUIREMENTS:
• Windows operating system
• 32-bit or 64-bit architecture

COMPILER OPTIONS (choose one):
1. Microsoft Visual Studio Build Tools
   - Download from: https://visualstudio.microsoft.com/downloads/
   - Install C++ build tools
   
2. MinGW-w64 Compiler
   - Download from: https://www.mingw-w64.org/
   - Or install via MSYS2: pacman -S mingw-w64-i686-gcc

BUILD PROCESS:
1. Open Command Prompt as Administrator
2. Navigate to the project directory
3. Run: build_dll.bat
4. Result: UniversalConverter32.dll

VERIFICATION:
• DLL should be ~50-200 KB in size
• Test with: test_dll_integration.py
• Import into VB6/VFP9 projects

DEPENDENCIES:
• Python 3.7+ must be installed
• cli.py must be in same directory as DLL
• requirements.txt packages must be installed
"""
        
        self.legacy_log(requirements)
    
    def generate_vb6_module(self):
        """Generate customized VB6 integration module"""
        self.legacy_log("Generating VB6 integration module...")
        
        try:
            # Read the production VB6 module
            vb6_source = Path("VB6_UniversalConverter_Production.bas")
            if not vb6_source.exists():
                self.legacy_log("❌ VB6 production module not found")
                return
            
            content = vb6_source.read_text()
            
            # Save to user's desktop or current directory
            import os
            desktop = Path.home() / "Desktop"
            if desktop.exists():
                output_path = desktop / "UniversalConverter_VB6.bas"
            else:
                output_path = Path("UniversalConverter_VB6.bas")
            
            output_path.write_text(content)
            self.legacy_log(f"✅ VB6 module generated: {output_path}")
            self.legacy_log("   Add this .bas file to your VB6 project")
            
        except Exception as e:
            self.legacy_log(f"❌ Error generating VB6 module: {str(e)}")
    
    def generate_vfp9_class(self):
        """Generate customized VFP9 integration class"""
        self.legacy_log("Generating VFP9 integration class...")
        
        try:
            # Read the production VFP9 class
            vfp9_source = Path("VFP9_UniversalConverter_Production.prg")
            if not vfp9_source.exists():
                self.legacy_log("❌ VFP9 production class not found")
                return
            
            content = vfp9_source.read_text()
            
            # Save to user's desktop or current directory
            import os
            desktop = Path.home() / "Desktop"
            if desktop.exists():
                output_path = desktop / "UniversalConverter_VFP9.prg"
            else:
                output_path = Path("UniversalConverter_VFP9.prg")
            
            output_path.write_text(content)
            self.legacy_log(f"✅ VFP9 class generated: {output_path}")
            self.legacy_log("   Include this .prg file in your VFP9 project")
            
        except Exception as e:
            self.legacy_log(f"❌ Error generating VFP9 class: {str(e)}")
    
    def test_vb6_integration(self):
        """Test VB6 DLL integration"""
        self.legacy_log("Testing VB6 DLL integration...")
        
        vb6_test = '''
' VB6 Test Code for UniversalConverter32.dll
Private Declare Function ConvertDocument Lib "UniversalConverter32.dll" _
    (ByVal inputFile As String, ByVal outputFile As String, _
     ByVal inputFormat As String, ByVal outputFormat As String) As Long

Private Declare Function TestConnection Lib "UniversalConverter32.dll" () As Long

Sub TestDLL()
    Dim result As Long
    
    ' Test if DLL is available
    result = TestConnection()
    If result = 1 Then
        MsgBox "✅ DLL is available and working!"
    Else
        MsgBox "❌ DLL test failed"
    End If
    
    ' Test conversion (modify paths as needed)
    result = ConvertDocument("C:\\temp\\test.txt", "C:\\temp\\test.md", "txt", "md")
    If result = 1 Then
        MsgBox "✅ Conversion successful!"
    Else
        MsgBox "❌ Conversion failed"
    End If
End Sub
'''
        
        self.legacy_log("VB6 Test Code:")
        self.legacy_log(vb6_test)
        self.legacy_log("Copy this code to a VB6 form and run TestDLL()")
    
    def test_vfp9_integration(self):
        """Test VFP9 DLL integration"""
        self.legacy_log("Testing VFP9 DLL integration...")
        
        vfp9_test = '''
*!* VFP9 Test Code for UniversalConverter32.dll
DECLARE INTEGER ConvertDocument IN UniversalConverter32.dll ;
    STRING inputFile, STRING outputFile, ;
    STRING inputFormat, STRING outputFormat

DECLARE INTEGER TestConnection IN UniversalConverter32.dll

PROCEDURE TestDLL()
    LOCAL lnResult
    
    *-- Test if DLL is available
    lnResult = TestConnection()
    IF lnResult = 1
        MESSAGEBOX("✅ DLL is available and working!")
    ELSE
        MESSAGEBOX("❌ DLL test failed")
    ENDIF
    
    *-- Test conversion (modify paths as needed)
    lnResult = ConvertDocument("C:\\temp\\test.txt", "C:\\temp\\test.md", "txt", "md")
    IF lnResult = 1
        MESSAGEBOX("✅ Conversion successful!")
    ELSE
        MESSAGEBOX("❌ Conversion failed")
    ENDIF
ENDPROC
'''
        
        self.legacy_log("VFP9 Test Code:")
        self.legacy_log(vfp9_test)
        self.legacy_log("Copy this code to a VFP9 program and run TestDLL")
    
    def browse_test_file(self):
        """Browse for a test file"""
        from tkinter import filedialog
        
        filename = filedialog.askopenfilename(
            title="Select Test File",
            filetypes=[
                ("All Supported", "*.pdf;*.docx;*.txt;*.html;*.md;*.rtf"),
                ("PDF files", "*.pdf"),
                ("Word documents", "*.docx"),
                ("Text files", "*.txt"),
                ("HTML files", "*.html"),
                ("Markdown files", "*.md"),
                ("RTF files", "*.rtf"),
                ("All files", "*.*")
            ]
        )
        
        if filename:
            self.test_file_path.set(filename)
            self.legacy_log(f"📁 Selected test file: {filename}")
    
    def test_dll_conversion(self):
        """Test DLL conversion functionality"""
        test_file = self.test_file_path.get()
        if not test_file:
            self.legacy_log("❌ No test file selected")
            return
        
        if not Path(test_file).exists():
            self.legacy_log("❌ Test file does not exist")
            return
        
        self.legacy_log(f"🧪 Testing DLL conversion: {test_file}")
        
        try:
            # Test CLI backend (which the DLL uses)
            import subprocess
            import tempfile
            
            with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as tmp:
                output_file = tmp.name
            
            cmd = [
                sys.executable, "cli.py", 
                test_file, 
                "-o", output_file, 
                "-t", "txt"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                if Path(output_file).exists():
                    # Read first few lines of output
                    content = Path(output_file).read_text()[:200]
                    self.legacy_log("✅ Conversion successful!")
                    self.legacy_log(f"   Output preview: {content}...")
                    
                    # Clean up
                    Path(output_file).unlink()
                else:
                    self.legacy_log("❌ Conversion completed but no output file")
            else:
                self.legacy_log(f"❌ Conversion failed: {result.stderr}")
                
        except Exception as e:
            self.legacy_log(f"❌ Test error: {str(e)}")
    
    def test_dll_functions(self):
        """Test individual DLL functions"""
        self.legacy_log("🔍 Testing DLL functions...")
        
        # Test the CLI backend that powers the DLL
        try:
            import subprocess
            
            # Test 1: CLI help
            result = subprocess.run([sys.executable, "cli.py", "--help"], 
                                  capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                self.legacy_log("✅ CLI help function working")
            else:
                self.legacy_log("❌ CLI help function failed")
            
            # Test 2: Format support
            result = subprocess.run([sys.executable, "cli.py", "--formats"], 
                                  capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                self.legacy_log("✅ Format detection working")
                self.legacy_log(f"   Supported formats: {result.stdout.strip()}")
            else:
                self.legacy_log("❌ Format detection failed")
            
            # Test 3: Version
            result = subprocess.run([sys.executable, "cli.py", "--version"], 
                                  capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                self.legacy_log("✅ Version function working")
                self.legacy_log(f"   Version: {result.stdout.strip()}")
            else:
                self.legacy_log("❌ Version function failed")
            
        except Exception as e:
            self.legacy_log(f"❌ Function test error: {str(e)}")
    
    def performance_test_dll(self):
        """Run performance test on DLL"""
        self.legacy_log("📊 Running performance test...")
        
        test_file = self.test_file_path.get()
        if not test_file or not Path(test_file).exists():
            self.legacy_log("❌ Need a valid test file for performance testing")
            return
        
        try:
            import subprocess
            import tempfile
            import time
            
            # Run multiple conversions and time them
            times = []
            for i in range(3):
                with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as tmp:
                    output_file = tmp.name
                
                start_time = time.time()
                
                cmd = [sys.executable, "cli.py", test_file, "-o", output_file, "-t", "txt", "--quiet"]
                result = subprocess.run(cmd, capture_output=True, timeout=30)
                
                end_time = time.time()
                duration = end_time - start_time
                times.append(duration)
                
                if result.returncode == 0:
                    self.legacy_log(f"✅ Test {i+1}: {duration:.2f} seconds")
                    Path(output_file).unlink()  # Clean up
                else:
                    self.legacy_log(f"❌ Test {i+1}: Failed")
            
            if times:
                avg_time = sum(times) / len(times)
                self.legacy_log(f"📊 Average conversion time: {avg_time:.2f} seconds")
                self.legacy_log(f"📊 Fastest: {min(times):.2f}s, Slowest: {max(times):.2f}s")
            
        except Exception as e:
            self.legacy_log(f"❌ Performance test error: {str(e)}")
    
    def create_dll_package(self):
        """Create distribution package for DLL"""
        self.legacy_log("📦 Creating DLL distribution package...")
        
        try:
            # Use the existing package builder
            import subprocess
            
            result = subprocess.run([sys.executable, "build_ocr_packages.py"], 
                                  capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                self.legacy_log("✅ Distribution package created successfully!")
                self.legacy_log(result.stdout)
                
                # Check if package was created
                package_path = Path("dist/UniversalConverter32.dll.zip")
                if package_path.exists():
                    size_kb = package_path.stat().st_size / 1024
                    self.legacy_log(f"📦 Package: {package_path} ({size_kb:.1f} KB)")
            else:
                self.legacy_log("❌ Package creation failed")
                self.legacy_log(result.stderr)
                
        except Exception as e:
            self.legacy_log(f"❌ Package creation error: {str(e)}")
    
    def install_dll_system(self):
        """Install DLL system-wide"""
        self.legacy_log("⚙️ Installing DLL system-wide...")
        
        try:
            dll_path = None
            for path in [Path("dist/UniversalConverter32.dll"), Path("UniversalConverter32.dll")]:
                if path.exists():
                    dll_path = path
                    break
            
            if not dll_path:
                self.legacy_log("❌ DLL not found - build it first")
                return
            
            import platform
            import shutil
            
            if platform.system() != "Windows":
                self.legacy_log("❌ System-wide installation requires Windows")
                return
            
            # Copy DLL to System32 (requires admin rights)
            system32 = Path(os.environ["WINDIR"]) / "System32"
            target = system32 / "UniversalConverter32.dll"
            
            try:
                shutil.copy2(dll_path, target)
                self.legacy_log(f"✅ DLL installed to: {target}")
                self.legacy_log("   DLL is now available system-wide")
            except PermissionError:
                self.legacy_log("❌ Installation failed - run as Administrator")
            except Exception as e:
                self.legacy_log(f"❌ Installation error: {str(e)}")
                
        except Exception as e:
            self.legacy_log(f"❌ System installation error: {str(e)}")
    
    def copy_integration_files(self):
        """Copy integration files to desktop"""
        self.legacy_log("📋 Copying integration files...")
        
        try:
            desktop = Path.home() / "Desktop"
            if not desktop.exists():
                desktop = Path(".")
            
            files_to_copy = [
                ("VB6_UniversalConverter_Production.bas", "VB6 Integration Module"),
                ("VFP9_UniversalConverter_Production.prg", "VFP9 Integration Class"),
                ("cli.py", "CLI Backend"),
                ("requirements.txt", "Python Dependencies"),
                ("README_DLL_Production.md", "Documentation")
            ]
            
            copied = 0
            for filename, description in files_to_copy:
                source = Path(filename)
                if source.exists():
                    target = desktop / filename
                    shutil.copy2(source, target)
                    self.legacy_log(f"✅ {description}: {target}")
                    copied += 1
                else:
                    self.legacy_log(f"❌ Missing: {filename}")
            
            self.legacy_log(f"📋 Copied {copied} files to {desktop}")
            
        except Exception as e:
            self.legacy_log(f"❌ Copy error: {str(e)}")
    
    def legacy_log(self, message):
        """Log message to legacy output area"""
        if hasattr(self, 'legacy_output'):
            timestamp = datetime.datetime.now().strftime("%H:%M:%S")
            self.legacy_output.insert(tk.END, f"[{timestamp}] {message}\n")
            self.legacy_output.see(tk.END)
        else:
            print(f"[LEGACY] {message}")
    
    def show_vb6_examples(self):
        """Show real VB6 DLL integration examples"""
        examples = """
REAL VB6 DLL INTEGRATION EXAMPLES:

1. BASIC DLL USAGE:
' Declare the DLL functions
Private Declare Function ConvertDocument Lib "UniversalConverter32.dll" _
    (ByVal inputFile As String, ByVal outputFile As String, _
     ByVal inputFormat As String, ByVal outputFormat As String) As Long

Private Declare Function TestConnection Lib "UniversalConverter32.dll" () As Long

' Test if DLL is available
Private Sub cmdTest_Click()
    Dim result As Long
    result = TestConnection()
    If result = 1 Then
        MsgBox "DLL is working!"
    Else
        MsgBox "DLL not available"
    End If
End Sub

2. DOCUMENT CONVERSION:
Private Sub cmdConvert_Click()
    Dim result As Long
    result = ConvertDocument("C:\\docs\\file.pdf", "C:\\docs\\file.txt", "pdf", "txt")
    If result = 1 Then
        MsgBox "Conversion successful!"
    Else
        MsgBox "Conversion failed!"
    End If
End Sub

3. USING THE PRODUCTION MODULE:
' Add VB6_UniversalConverter_Production.bas to your project
Private Sub cmdAdvanced_Click()
    If InitializeConverter() Then
        If PDFToText("C:\\temp\\document.pdf", "C:\\temp\\output.txt") Then
            MsgBox "PDF converted to text successfully!"
        Else
            MsgBox "Error: " & GetLastErrorMessage()
        End If
    End If
End Sub
"""
        
        self.legacy_log(examples)
    
    def show_vfp9_examples(self):
        """Show real VFP9 DLL integration examples"""
        examples = """
REAL VFP9 DLL INTEGRATION EXAMPLES:

1. BASIC DLL USAGE:
*-- Declare the DLL functions
DECLARE INTEGER ConvertDocument IN UniversalConverter32.dll ;
    STRING inputFile, STRING outputFile, ;
    STRING inputFormat, STRING outputFormat

DECLARE INTEGER TestConnection IN UniversalConverter32.dll

*-- Test if DLL is available
lnResult = TestConnection()
IF lnResult = 1
    MESSAGEBOX("DLL is working!")
ELSE
    MESSAGEBOX("DLL not available")
ENDIF

2. DOCUMENT CONVERSION:
lnResult = ConvertDocument("C:\\docs\\file.pdf", "C:\\docs\\file.txt", "pdf", "txt")
IF lnResult = 1
    MESSAGEBOX("Conversion successful!")
ELSE
    MESSAGEBOX("Conversion failed!")
ENDIF

3. USING THE PRODUCTION CLASS:
*-- Include VFP9_UniversalConverter_Production.prg in your project
loConverter = CREATEOBJECT("UniversalConverter")

IF loConverter.lInitialized
    llSuccess = loConverter.PDFToText("C:\\temp\\document.pdf", "C:\\temp\\output.txt")
    IF llSuccess
        MESSAGEBOX("PDF converted successfully!")
    ELSE
        MESSAGEBOX("Error: " + loConverter.cLastError)
    ENDIF
ELSE
    MESSAGEBOX("Converter not available")
ENDIF

4. BATCH CONVERSION:
loConverter = CREATEOBJECT("UniversalConverter")
lnConverted = loConverter.ConvertDirectory("C:\\PDFs", "C:\\Text", "pdf", "txt")
MESSAGEBOX(TRANSFORM(lnConverted) + " files converted")
"""
        
        self.legacy_log(examples)
    
    def open_integration_guide(self):
        """Open VB6/VFP9 integration guide"""
        guide_path = Path(__file__).parent / "VFP9_VB6_INTEGRATION_GUIDE.md"
        if guide_path.exists():
            try:
                webbrowser.open(f"file://{guide_path}")
            except Exception as e:
                logging.error(f"Failed to open integration guide: {e}")
                messagebox.showerror("Error", f"Failed to open integration guide: {e}")
        else:
            messagebox.showwarning("Guide Not Found", "Integration guide not found in current directory")
    
    # Settings methods
    def save_settings(self):
        """Save current settings"""
        # Update config with current values
        self.config['gui']['theme'] = self.theme_var.get()
        self.config['conversion']['preserve_formatting'] = self.preserve_formatting.get()
        self.config['gui']['auto_preview'] = self.auto_preview.get()
        self.config['conversion']['max_workers'] = self.max_workers.get()
        self.config['ocr']['use_cache'] = self.ocr_use_cache.get()
        self.config['logging']['level'] = self.log_level.get()
        self.config['api']['google_vision']['enabled'] = self.gv_enabled.get()
        self.config['api']['google_vision']['credentials_path'] = self.gv_credentials.get()
        self.config['api']['google_vision']['fallback_enabled'] = self.gv_fallback_enabled.get()
        # Note: legacy_enabled is always True for this version
        
        self.save_config()
        messagebox.showinfo("Settings Saved", "Settings have been saved successfully")
    
    def reset_settings(self):
        """Reset settings to defaults"""
        if messagebox.askyesno("Reset Settings", "Are you sure you want to reset all settings to defaults?"):
            # Reset to default config
            self.config = self.load_config()  # This will load defaults if no config exists
            
            # Update UI elements
            self.theme_var.set(self.config['gui']['theme'])
            self.preserve_formatting.set(self.config['conversion']['preserve_formatting'])
            self.auto_preview.set(self.config['gui']['auto_preview'])
            self.max_workers.set(self.config['conversion']['max_workers'])
            self.ocr_use_cache.set(self.config['ocr']['use_cache'])
            self.log_level.set(self.config['logging']['level'])
            self.gv_enabled.set(self.config['api']['google_vision']['enabled'])
            self.gv_credentials.set(self.config['api']['google_vision']['credentials_path'])
            self.gv_fallback_enabled.set(self.config['api']['google_vision'].get('fallback_enabled', True))
            # Legacy integration is always enabled in this version
            
            messagebox.showinfo("Settings Reset", "Settings have been reset to defaults")
    
    def open_config_folder(self):
        """Open configuration folder"""
        config_dir = Path.home() / ".universal_converter"
        if config_dir.exists():
            try:
                webbrowser.open(f"file://{config_dir}")
            except Exception as e:
                logging.error(f"Failed to open configuration folder: {e}")
                messagebox.showerror("Error", f"Failed to open configuration folder: {e}")
        else:
            messagebox.showwarning("Folder Not Found", "Configuration folder does not exist yet")
    
    # Utility methods
    def update_status(self, message: str):
        """Update status label (thread-safe)"""
        self.root.after(0, lambda: self.status_label.config(text=message))
    
    def update_progress(self, value: float):
        """Update progress bar (thread-safe)"""
        self.root.after(0, lambda: self.progress_var.set(value))
    
    def update_progress_with_eta(self, progress: float, completed: int, total: int):
        """Update progress with ETA calculation"""
        def update():
            self.progress_var.set(progress)
            
            if self.start_time and completed > 0:
                elapsed = time.time() - self.start_time
                rate = completed / elapsed
                remaining = total - completed
                eta_seconds = remaining / rate if rate > 0 else 0
                
                # Format time
                if eta_seconds < 60:
                    eta_str = f"{int(eta_seconds)}s"
                elif eta_seconds < 3600:
                    eta_str = f"{int(eta_seconds / 60)}m {int(eta_seconds % 60)}s"
                else:
                    hours = int(eta_seconds / 3600)
                    minutes = int((eta_seconds % 3600) / 60)
                    eta_str = f"{hours}h {minutes}m"
                
                detail_text = f"{completed}/{total} files | ETA: {eta_str}"
                if self.failed_count > 0:
                    detail_text += f" | {self.failed_count} failed"
                if self.skipped_count > 0:
                    detail_text += f" | {self.skipped_count} skipped"
                
                self.progress_detail_label.config(text=detail_text)
            
        self.root.after(0, update)
    
    def get_cache_key(self, file_path: str, output_format: str) -> str:
        """Generate cache key based on file content and format"""
        try:
            # Get file modification time and size
            stat = Path(file_path).stat()
            mtime = stat.st_mtime
            size = stat.st_size
            
            # Create cache key
            key_string = f"{file_path}:{output_format}:{mtime}:{size}"
            return hashlib.md5(key_string.encode()).hexdigest()
        except (OSError, AttributeError) as e:
            self.logger.debug(f"Could not generate cache key: {e}")
            return None
    
    def get_cached_result(self, cache_key: str) -> Optional[bytes]:
        """Get cached conversion result"""
        with self.cache_lock:
            return self.conversion_cache.get(cache_key)
    
    def cache_result(self, cache_key: str, content: bytes):
        """Cache conversion result with size management"""
        with self.cache_lock:
            content_size = len(content)
            
            # Clear cache if adding this would exceed limit
            if self.current_cache_size + content_size > self.max_cache_size:
                self.clear_cache()
            
            self.conversion_cache[cache_key] = content
            self.current_cache_size += content_size
    
    def clear_cache(self):
        """Clear the conversion cache"""
        with self.cache_lock:
            self.conversion_cache.clear()
            self.current_cache_size = 0
            gc.collect()
    
    def refresh_thread_info(self):
        """Refresh thread information display"""
        self.thread_count_label.config(text=str(threading.active_count()))
        
        # Clear and update thread list
        self.thread_listbox.delete(0, tk.END)
        for thread in threading.enumerate():
            thread_info = f"{thread.name} - {'Alive' if thread.is_alive() else 'Dead'} - Daemon: {thread.daemon}"
            self.thread_listbox.insert(tk.END, thread_info)
    
    def update_memory_info(self):
        """Update memory usage information"""
        try:
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            
            # Cache information - access with lock
            with self.cache_lock:
                cache_size_mb = self.current_cache_size / 1024 / 1024
                cache_entries = len(self.conversion_cache)
            
            info_text = f"""Memory Usage Information:
- RSS (Resident Set Size): {memory_info.rss / 1024 / 1024:.2f} MB
- VMS (Virtual Memory Size): {memory_info.vms / 1024 / 1024:.2f} MB
- Available System Memory: {psutil.virtual_memory().available / 1024 / 1024:.2f} MB
- Memory Percent: {process.memory_percent():.2f}%
- Python Objects: {len(gc.get_objects())} objects

Cache Information:
- Cache Size: {cache_size_mb:.2f} MB / {self.max_cache_size / 1024 / 1024:.0f} MB
- Cached Items: {cache_entries} files"""
            
            # Add memory optimization button if memory usage is high
            if memory_info.rss > config_manager.get('performance.memory_threshold_mb', 500) * 1024 * 1024:  # Configurable memory threshold
                info_text += "\n\n⚠️ High memory usage detected!"
            
        except ImportError:
            # Access cache with lock
            with self.cache_lock:
                cache_size_mb = self.current_cache_size / 1024 / 1024
                cache_entries = len(self.conversion_cache)
                
            info_text = f"""Memory monitoring requires psutil package.
Install with: pip install psutil

Basic memory info:
- Python objects in memory: {len(gc.get_objects())} objects

Cache Information:
- Cache Size: {cache_size_mb:.2f} MB
- Cached Items: {cache_entries} files"""
        
        self.memory_info_text.delete(1.0, tk.END)
        self.memory_info_text.insert(tk.END, info_text)
    
    def optimize_memory(self):
        """Optimize memory usage"""
        self.update_status("Optimizing memory...")
        
        # Clear cache if it's large - check size with lock
        with self.cache_lock:
            should_clear = self.current_cache_size > 50 * 1024 * 1024  # > 50MB
        
        if should_clear:
            self.clear_cache()
        
        # Force garbage collection
        collected = gc.collect()
        
        # Update memory info
        self.update_memory_info()
        
        self.update_status(f"Memory optimized - {collected} objects collected")
        messagebox.showinfo("Memory Optimization", f"Memory optimization complete!\n{collected} objects collected.\nCache cleared if it was over 50MB.")
    
    def process_ocr_with_fallback(self, file_path, options):
        """Process OCR with automatic fallback to free engines if API fails"""
        original_engine = options.get('engine', 'auto')
        result = None
        fallback_used = False
        
        try:
            # First try with the selected engine
            result = self.ocr_engine.extract_text(file_path, options)
            
            # Check if Google Vision API failed
            if (original_engine == 'google_vision' or (original_engine == 'auto' and self.gv_enabled.get())) and \
               (not result or result.get('text', '').strip() == '' or 'error' in str(result).lower()):
                
                # Log the API failure
                self.logger.warning("Google Vision API failed, attempting fallback to free engine")
                
                # Try fallback engines in order
                fallback_engines = ['tesseract', 'easyocr']
                for fallback_engine in fallback_engines:
                    try:
                        self.logger.info(f"Trying fallback engine: {fallback_engine}")
                        fallback_options = options.copy()
                        fallback_options['engine'] = fallback_engine
                        
                        fallback_result = self.ocr_engine.extract_text(file_path, fallback_options)
                        
                        if fallback_result and fallback_result.get('text', '').strip():
                            result = fallback_result
                            result['fallback_used'] = True
                            result['original_engine'] = original_engine
                            fallback_used = True
                            
                            # Track API failures
                            if hasattr(self, '_api_failure_count'):
                                self._api_failure_count += 1
                            else:
                                self._api_failure_count = 1
                            
                            # Show warning every 5 failures
                            if self._api_failure_count % 5 == 1:
                                self.root.after(0, lambda: messagebox.showwarning(
                                    "API Fallback Active",
                                    f"Google Vision API failed. Using {fallback_engine} as fallback.\n\n"
                                    "This may be due to:\n"
                                    "• API quota exceeded\n"
                                    "• Billing issues\n"
                                    "• Network problems\n\n"
                                    "Check your API settings and credentials."
                                ))
                            
                            # Update OCR engine indicator
                            self.root.after(0, lambda: self.ocr_status_label.config(
                                text=f"⚠️ OCR Engine: {fallback_engine.title()} (API Fallback)"
                            ))
                            break
                            
                    except Exception as e:
                        self.logger.error(f"Fallback engine {fallback_engine} failed: {e}")
                        continue
                        
        except Exception as e:
            self.logger.error(f"OCR processing error: {e}")
            # If primary engine fails, try fallback
            if original_engine == 'google_vision' or (original_engine == 'auto' and self.gv_enabled.get()):
                try:
                    fallback_options = options.copy()
                    fallback_options['engine'] = 'tesseract'  # Default fallback
                    result = self.ocr_engine.extract_text(file_path, fallback_options)
                    if result:
                        result['fallback_used'] = True
                        result['original_engine'] = original_engine
                        
                        # Update indicator
                        self.root.after(0, lambda: self.ocr_status_label.config(
                            text="⚠️ OCR Engine: Tesseract (API Error Fallback)"
                        ))
                except Exception as e:
                    self.logger.debug(f"Could not update OCR status: {e}")
                    pass
        
        # Update configuration if needed to remember preference
        if fallback_used and self.config.get('api', {}).get('google_vision', {}).get('fallback_enabled', True):
            # Store last successful fallback engine in session
            if not hasattr(self, '_last_successful_fallback'):
                self._last_successful_fallback = result.get('engine_used', 'tesseract')
        
        return result or {'text': '', 'confidence': 0, 'error': 'All OCR engines failed'}
    
    def on_closing(self):
        """Handle application closing"""
        if self.is_processing:
            if messagebox.askokcancel("Quit", "Processing is in progress. Do you want to quit?"):
                self.cancel_processing = True
                if self.processing_thread and self.processing_thread.is_alive():
                    self.processing_thread.join(timeout=2)
                self.cleanup_resources()
                self.root.destroy()
        else:
            self.save_config()  # Save settings on exit
            self.cleanup_resources()
            self.root.destroy()
    
    def cleanup_resources(self):
        """Clean up file handlers and other resources"""
        # Close logging handlers
        if hasattr(self, 'file_handler'):
            self.file_handler.close()
        if hasattr(self, 'stream_handler'):
            self.stream_handler.close()
        
        # Clean up OCR engine
        if hasattr(self, 'ocr_engine') and self.ocr_engine:
            try:
                self.ocr_engine.cleanup()
            except Exception as e:
                self.logger.error(f"Error cleaning up OCR engine: {e}")

    def update_api_stats(self, message):
        """Update API statistics display"""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Get current content
        self.api_stats.config(state=tk.NORMAL)
        current_text = self.api_stats.get(1.0, tk.END).strip()
        
        # Add new message
        if current_text and current_text != "API statistics will appear here...":
            new_text = f"{current_text}\n[{timestamp}] {message}"
        else:
            new_text = f"[{timestamp}] {message}"
        
        # Limit to last 100 lines
        lines = new_text.split('\n')
        if len(lines) > 100:
            lines = lines[-100:]
            new_text = '\n'.join(lines)
        
        self.api_stats.delete(1.0, tk.END)
        self.api_stats.insert(tk.END, new_text)
        self.api_stats.see(tk.END)
        self.api_stats.config(state=tk.DISABLED)

def main():
    """Main application entry point"""
    root = tk.Tk()
    
    # Enable drag and drop
    try:
        from tkinterdnd2 import TkinterDnD
        root = TkinterDnD.Tk()
    except ImportError:
        pass
    
    app = UniversalDocumentConverter(root)
    root.mainloop()

if __name__ == "__main__":
    main()